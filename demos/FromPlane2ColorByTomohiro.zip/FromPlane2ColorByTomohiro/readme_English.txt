FromPlane2Color
PC 64k (or 5k) intro for Tokyo Demo Fest 2011
by Tomohiro

This is a 2D Graphics demo.
This program dont use OpenGL, DirectX, OpenCL, PhysX and CUDA.
Value of all pixels are calculated by only CPU.
This program dont have any sound.
Source code of this program is placed in
'src_learn_modify_and_reuse' directory.

I refered this page
http://iquilezles.org/
when making this demo.
Thank you very much!

System requirement
--------
OS: WindowsXP, WindowsVista or Windows7
CPU: support SSE3
(This program uses only 1 thread. Many core CPU is meaningless.)


Credit
--------
Code: Tomohiro

Tools
--------
Crinkler:
Thank you very very much for Crinkler!
gvim:
If it was not exist, I could not write any codes.
Microsoft Visual C++ 2008 Express Edition:
If it was not exist, I would use g++ and Boost.Build.

API:
--------
win32api
SSE3
GDI

contact:
--------
gpuppur@gmail.com
http://twitter.com/demotomohiro
