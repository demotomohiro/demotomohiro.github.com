#ifndef SOUND_CONF_H
#define SOUND_CONF_H

#define SOUND_SAMPLE_RATE		44100
#define SOUND_LENGTH_IN_SECOND	60

#endif
