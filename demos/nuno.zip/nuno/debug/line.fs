#version 140

out vec4 C;

void main()
{
	C = vec4(1.0, 0.0, 0.0, 1.0);
}
